# Install and import required libraries
library(shiny)
library(ggplot2)
library(leaflet)
library(tidyverse)
library(httr)
library(scales)
# Import model_prediction R which contains methods to call OpenWeather API
# and make predictions
source("model_prediction.R")

test_weather_data_generation <- function(){
  city_weather_bike_df <- generate_city_weather_bike_data()
  stopifnot(length(city_weather_bike_df) > 0)
  print(head(city_weather_bike_df))
  return(city_weather_bike_df)
}

# Create a RShiny server
shinyServer(function(input, output){
  # Define a city list
  city_list <- c("New York, USA", "Paris, France", "Suzhou, China", "London, UK", "Seoul, South Korea")
  # Define color factor
  color_levels <- colorFactor(c("green", "yellow", "red"), 
                              levels = c("small", "medium", "large"))
  
  # Test generate_city_weather_bike_data() function
  city_weather_bike_df <- test_weather_data_generation()
  
  # Create another data frame called `cities_max_bike` with each row contains city location info and max bike
  # prediction for the city
  cities_max_bike <- city_weather_bike_df %>% 
    group_by(CITY_ASCII, LNG, LAT) %>% 
    summarize(
      max_bike = max(BIKE_PREDICTION, na.rm = TRUE), 
      LABEL = first(LABEL[which.max(BIKE_PREDICTION)]),
      DETAILED_LABEL = first(DETAILED_LABEL[which.max(BIKE_PREDICTION)]), 
      .groups = "drop"
    ) %>%
    mutate(
      BIKE_PREDICTION_LEVEL = case_when(
        max_bike < 1000 ~ "small", 
        max_bike < 5000 ~ "medium", 
        TRUE ~ "large"
      )
    )
  
  # Create reactive value for clicked point - ADD THIS LINE
  clicked_point <- reactiveVal(NULL)
  
  # Observe drop-down event
  observeEvent(input$city_dropdown, {
    if(input$city_dropdown != 'All') {
      selected_city_data <- cities_max_bike %>%
        filter(CITY_ASCII == input$city_dropdown)
      
      city_detail <- city_weather_bike_df %>%
        filter(CITY_ASCII == input$city_dropdown) %>%
        arrange(FORECASTDATETIME)
      
      output$city_bike_map <- renderLeaflet({
        leaflet(selected_city_data) %>%  # Use selected_city_data instead of city_detail
          addTiles() %>%
          addCircleMarkers(
            lng = ~LNG, 
            lat = ~LAT,
            radius = ~case_when(
              BIKE_PREDICTION_LEVEL == "small" ~ 6,
              BIKE_PREDICTION_LEVEL == "medium" ~ 10,
              BIKE_PREDICTION_LEVEL == "large" ~ 12
            ),
            color = ~color_levels(BIKE_PREDICTION_LEVEL),
            popup = ~DETAILED_LABEL,
            stroke = FALSE,
            fillOpacity = 0.8
          )
      })
      
      output$temp_line <- renderPlot({
        ggplot(data = city_detail, aes(x = as.POSIXct(FORECASTDATETIME), y = TEMPERATURE)) + 
          geom_line(color = "orange", size = 1.2) +  geom_point(color = "darkorange", size = 3) +
          labs(title = paste("Temperature Trend for", input$city_dropdown), x = "Forecast Date & Time", y = "Temperature (°C)") +
          theme_minimal() + scale_x_datetime(date_labels = "%m/%d %H:%M") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1))
      })
      
      output$bike_line <- renderPlot({
        p <- ggplot(data = city_detail, aes(x = as.POSIXct(FORECASTDATETIME), y = BIKE_PREDICTION)) + 
          geom_line(color = "blue", size = 1.2) +  geom_point(color = "darkblue", size = 3) +
          labs(title = paste("Bike Prediction Trend for", input$city_dropdown), x = "Forecast Date & Time", 
               y = "Bike Prediction") + theme_minimal() + scale_x_datetime(date_labels = "%m/%d %H:%M") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1))
        
        if (!is.null(clicked_point())) {
          p <- p + 
            geom_point(data = clicked_point(), aes(x = as.POSIXct(FORECASTDATETIME), y = BIKE_PREDICTION), 
                       color = "red", size = 5, shape = 1, stroke = 2)}
        p
      })
      
      observeEvent(input$plot_click, {
        click_data <- input$plot_click
        
        if (!is.null(click_data)) {
          clicked_time <- as.POSIXct(click_data$x, origin = "1970-01-01")
          city_detail$time_diff <- abs(as.numeric(as.POSIXct(city_detail$FORECASTDATETIME) - clicked_time))
          closest_point <- city_detail[which.min(city_detail$time_diff), ]
          clicked_point(closest_point)
        }
      })
      
      output$bike_date_output <- renderText({
        if (!is.null(clicked_point())) {
          point <- clicked_point()
          paste("Time: ", point$FORECASTDATETIME, 
                "\nBike Prediction: ", round(point$BIKE_PREDICTION))
        } else {
          "Click on the bike prediction graph to see details for a specific time point"
        }
      })
      
      output$humidity_pred_chart <- renderPlot({
        ggplot(data = city_detail, aes(x = HUMIDITY, y = BIKE_PREDICTION)) + 
          geom_smooth(method = "lm", formula = y ~ poly(x, 4), color = "green", size = 1.2, alpha = 0.7) + 
          geom_point(color = "darkgreen", size = 3) +
          labs(title = paste("Humidity vs Bike Prediction for", input$city_dropdown), x = "Humidity (%)", 
               y = "Bike Prediction") + theme_minimal()
      })
      
    } else {
      clicked_point(NULL)
      
      output$city_bike_map <- renderLeaflet({
        leaflet(cities_max_bike) %>%
          addTiles() %>%
          addCircleMarkers(lng = ~LNG, lat = ~LAT,
            radius = ~case_when(BIKE_PREDICTION_LEVEL == "small" ~ 6, BIKE_PREDICTION_LEVEL == "medium" ~ 10,
                                BIKE_PREDICTION_LEVEL == "large" ~ 12),
            color = ~color_levels(BIKE_PREDICTION_LEVEL), popup = ~LABEL, stroke = FALSE, fillOpacity = 0.8)
      })
      
      output$temp_line <- renderPlot({
        ggplot() + 
          annotate("text", x = 0.5, y = 0.5, label = "Select a specific city to view temperature trend", 
                   size = 5, color = "gray") + theme_void()
      })
      
      output$bike_line <- renderPlot({
        ggplot() + 
          annotate("text", x = 0.5, y = 0.5, label = "Select a specific city to view bike prediction trend", 
                   size = 5, color = "gray") + theme_void()
      })
      
      output$humidity_pred_chart <- renderPlot({
        ggplot() + 
          annotate("text", x = 0.5, y = 0.5, label = "Select a specific city to view\nhumidity and bike-sharing demand prediction correlation plot", 
                   size = 5, color = "gray") + theme_void()
      })
      
      output$bike_date_output <- renderText({ 
        "Select a specific city to view detailed trend information"
      })
    }
  })
})
